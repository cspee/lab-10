# Lab10-code-generation


## Class diagram
![ClassDiagram](https://github.com/kotovro/Lab10-code-generation/blob/master/src/main/resources/AClassDiagram.jpg)
## Sequence diagram
![SequenceDiagram](https://github.com/kotovro/Lab10-code-generation/blob/master/src/main/resources/Sequence%20Diagram1.jpg)
## Use case diagram
![Use Case diagram](https://github.com/kotovro/Lab10-code-generation/blob/master/src/main/resources/Use%20Case%20Diagram2.jpg)

## Activity diagram
![Activity digram](https://github.com/kotovro/Lab10-code-generation/blob/master/src/main/resources/Activity%20Diagram1.jpg)

## Reversed diagram
![Reversed diagram](https://github.com/kotovro/Lab10-code-generation/blob/master/src/main/resources/Model.main.jpg)
