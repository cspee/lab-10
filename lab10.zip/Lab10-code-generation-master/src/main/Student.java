package main;

public class Student {

	public int full_name;

	public void study() {
		// TODO - implement Student.study
		throw new UnsupportedOperationException();
	}

	public int getFull_name() {
		return this.full_name;
	}

	/**
	 * 
	 * @param full_name
	 */
	public void setFull_name(int full_name) {
		this.full_name = full_name;
	}

}