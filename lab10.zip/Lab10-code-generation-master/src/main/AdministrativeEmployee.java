package main;

public class AdministrativeEmployee extends Employee {

	public void organizeTheLearningProcess() {
		// TODO - implement AdministrativeEmployee.organizeTheLearningProcess
		throw new UnsupportedOperationException();
	}

	public String doAdministrativePaperWork() {
		// TODO - implement AdministrativeEmployee.doAdministrativePaperWork
		throw new UnsupportedOperationException();
	}

}