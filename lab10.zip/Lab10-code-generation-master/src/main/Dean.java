package main;

public class Dean extends Employee {

	public int SSnumber;
	public String name;
	public String email;
	public int number_employee;

	public void managementOfTheFaculty() {
		// TODO - implement Dean.managementOfTheFaculty
		throw new UnsupportedOperationException();
	}

	public String viewEducationPlans() {
		// TODO - implement Dean.viewEducationPlans
		throw new UnsupportedOperationException();
	}

	public int getSSnumber() {
		// TODO - implement Dean.getSSnumber
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	public int getNumber_employee() {
		return this.number_employee;
	}

	/**
	 * 
	 * @param number_employee
	 */
	public void setNumber_employee(int number_employee) {
		this.number_employee = number_employee;
	}

}