package main;

public class ResearchEmployee extends Employee {

	public String field_of_study;

	public String doResearchPaperWork() {
		// TODO - implement ResearchEmployee.doResearchPaperWork
		throw new UnsupportedOperationException();
	}

	public void superviseTheResearchFieldOfStudents() {
		// TODO - implement ResearchEmployee.superviseTheResearchFieldOfStudents
		throw new UnsupportedOperationException();
	}

	public String getField_of_study() {
		return this.field_of_study;
	}

	/**
	 * 
	 * @param field_of_study
	 */
	public void setField_of_study(String field_of_study) {
		this.field_of_study = field_of_study;
	}

}