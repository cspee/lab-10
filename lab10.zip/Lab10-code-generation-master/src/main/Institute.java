package main;

public class Institute {

	public String name;
	public String address;

	public void conductingResearchWork() {
		// TODO - implement Institute.conductingResearchWork
		throw new UnsupportedOperationException();
	}

	public void studentSupervision() {
		// TODO - implement Institute.studentSupervision
		throw new UnsupportedOperationException();
	}

	public String getName() {
		return this.name;
	}

	public String getAddress() {
		return this.address;
	}

	/**
	 * 
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

}