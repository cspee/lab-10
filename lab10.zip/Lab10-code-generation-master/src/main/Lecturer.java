package main;

public class Lecturer extends ResearchEmployee {

	public void teach() {
		// TODO - implement Lecturer.teach
		throw new UnsupportedOperationException();
	}

	public String createATrainingProgram() {
		// TODO - implement Lecturer.createATrainingProgram
		throw new UnsupportedOperationException();
	}

	public int giveMarksToStudents() {
		// TODO - implement Lecturer.giveMarksToStudents
		throw new UnsupportedOperationException();
	}

}